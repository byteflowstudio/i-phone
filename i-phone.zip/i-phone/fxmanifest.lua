-- fxmanifest.lua
fx_version 'cerulean'
game 'gta5'

author 'ByteFlow Studio'
description 'Custom UI with bank, chat, phone, and photo system'
version '1.0.0'

server_scripts {
    'server/main.lua',
    'server/config.lua'
}

client_scripts {
    'client/main.lua',
    'client/config.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css'
}

dependencies {
    'es_extended',
    'esx_society'
}