Citizen.CreateThread(function()
    -- Initialize NUI Callbacks
    RegisterNUICallback('openBank', function()
        ESX.TriggerServerCallback('byteflow:getBankBalance', function(balance)
            SendNUIMessage({ action = 'updateBalance', balance = balance })
        end)
    end)

    RegisterNUICallback('transferMoney', function(data, cb)
        local targetId = data.targetId
        local amount = tonumber(data.amount)
        TriggerServerEvent('byteflow:transferMoney', targetId, amount)
        cb('ok')
    end)

    RegisterNUICallback('chatMessage', function(data)
        local message = data.message
        TriggerServerEvent('byteflow:sendMessage', message)
    end)

    RegisterNUICallback('makeCall', function(data)
        local targetId = data.targetId
        TriggerServerEvent('byteflow:makeCall', targetId)
    end)

    RegisterNUICallback('takePhoto', function(data)
        -- Placeholder for Photo logic
        console.log('Taking photo...')
    end)
end)