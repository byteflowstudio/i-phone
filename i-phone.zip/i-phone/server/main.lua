ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- Bank Account System
RegisterServerEvent('byteflow:getBankBalance')
AddEventHandler('byteflow:getBankBalance', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local balance = xPlayer.getAccount('bank').money
    TriggerClientEvent('byteflow:sendBankBalance', source, balance)
end)

RegisterServerEvent('byteflow:transferMoney')
AddEventHandler('byteflow:transferMoney', function(targetId, amount)
    local sourcePlayer = ESX.GetPlayerFromId(source)
    local targetPlayer = ESX.GetPlayerFromId(targetId)
    
    if sourcePlayer.getAccount('bank').money >= amount then
        sourcePlayer.removeAccountMoney('bank', amount)
        targetPlayer.addAccountMoney('bank', amount)
        TriggerClientEvent('byteflow:notify', source, 'Transfer successful!')
        TriggerClientEvent('byteflow:notify', targetId, 'You have received money!')
    else
        TriggerClientEvent('byteflow:notify', source, 'Insufficient funds!')
    end
end)

-- Chat System
RegisterServerEvent('byteflow:sendMessage')
AddEventHandler('byteflow:sendMessage', function(message)
    local playerName = GetPlayerName(source)
    TriggerClientEvent('chat:addMessage', -1, {
        args = { playerName, message },
        color = { 255, 255, 255 }
    })
end)

-- Phone System
RegisterServerEvent('byteflow:makeCall')
AddEventHandler('byteflow:makeCall', function(targetId)
    local targetPlayer = ESX.GetPlayerFromId(targetId)
    if targetPlayer then
        TriggerClientEvent('byteflow:receiveCall', targetId, source)
    else
        TriggerClientEvent('byteflow:notify', source, 'Player is unavailable.')
    end
end)